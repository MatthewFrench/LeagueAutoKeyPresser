//
//  AppDelegate.h
//  Key Press Test
//
//  Created by Matthew French on 4/4/15.
//  Copyright (c) 2015 Matthew French. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate> {

}
- (IBAction)turnOnOff:(id)sender;
- (IBAction)active1OnOff:(id)sender;
- (IBAction)active2OnOff:(id)sender;
- (IBAction)active3OnOff:(id)sender;
- (IBAction)active5OnOff:(id)sender;
- (IBAction)active6OnOff:(id)sender;
- (IBAction)active7OnOff:(id)sender;
- (IBAction)activeWardOnOff:(id)sender;

- (IBAction)qValueChanged:(NSTextField*)sender;
- (IBAction)wValueChanged:(NSTextField*)sender;
- (IBAction)eValueChanged:(NSTextField*)sender;
- (IBAction)rValueChanged:(NSTextField*)sender;
- (IBAction)activeValueChanged:(NSTextField*)sender;
- (IBAction)activeKeyChanged:(NSComboBox*)sender;

@end

