//
//  AppDelegate.h
//  Key Press Test
//
//  Created by Matthew French on 4/4/15.
//  Copyright (c) 2015 Matthew French. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate> {

}
- (IBAction)turnOnOff:(NSButton*)sender;
- (IBAction)active1OnOff:(id)sender;
- (IBAction)active2OnOff:(id)sender;
- (IBAction)active3OnOff:(id)sender;
- (IBAction)active5OnOff:(id)sender;
- (IBAction)active6OnOff:(id)sender;
- (IBAction)active7OnOff:(id)sender;
- (IBAction)activeWardOnOff:(id)sender;

- (IBAction)qPreactivateW:(id)sender;
- (IBAction)qPreactivateE:(id)sender;
- (IBAction)qPreactivateR:(id)sender;

- (IBAction)wPreactivateQ:(id)sender;
- (IBAction)wPreactivateE:(id)sender;
- (IBAction)wPreactivateR:(id)sender;

- (IBAction)ePreactivateQ:(id)sender;
- (IBAction)ePreactivateW:(id)sender;
- (IBAction)ePreactivateR:(id)sender;

- (IBAction)rPreactivateQ:(id)sender;
- (IBAction)rPreactivateW:(id)sender;
- (IBAction)rPreactivateE:(id)sender;

- (IBAction)wardHopOnOff:(id)sender;
- (IBAction)wardHopKeyChanged:(NSComboBox*)sender;

- (IBAction)qValueChanged:(NSTextField*)sender;
- (IBAction)wValueChanged:(NSTextField*)sender;
- (IBAction)eValueChanged:(NSTextField*)sender;
- (IBAction)rValueChanged:(NSTextField*)sender;
- (IBAction)activeValueChanged:(NSTextField*)sender;
- (IBAction)activeKeyChanged:(NSComboBox*)sender;

@end

