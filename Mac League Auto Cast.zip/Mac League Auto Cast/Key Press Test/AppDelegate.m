//
//  AppDelegate.m
//  Key Press Test
//
//  Created by Matthew French on 4/4/15.
//  Copyright (c) 2015 Matthew French. All rights reserved.
//

#import "AppDelegate.h"
#import <ApplicationServices/ApplicationServices.h>

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

NSTimer* timer = NULL;

bool keyQPressed = 0;
bool keyWPressed = 0;
bool keyEPressed = 0;
bool keyRPressed = 0;

bool pressingSpell1 = false;
bool pressingSpell2 = false;
bool pressingSpell3 = false;
bool pressingSpell4 = false;

CFTimeInterval pressingSpell1LastTime = 0;
CFTimeInterval pressingSpell2LastTime = 0;
CFTimeInterval pressingSpell3LastTime = 0;
CFTimeInterval pressingSpell4LastTime = 0;

CFTimeInterval pressingActivesLastTime = 0;

CFTimeInterval pressingWardLastTime = 0;

double pressSpell1Interval = 10;
double pressSpell2Interval = 10;
double pressSpell3Interval = 10;
double pressSpell4Interval = 130;
double pressActivesInterval = 500;

bool running = true;
bool active1On = false;
bool active2On = true;
bool active3On = true;
bool active5On = false;
bool active6On = false;
bool active7On = false;
bool activeWardOn = true;

char activeKey = 'E';


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    globalSelf = self;
    [self createTap];
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0/120.0
                                             target:self
                                           selector:@selector(timerLogic)
                                           userInfo:nil
                                            repeats:YES];
    
    pressingSpell1LastTime = CACurrentMediaTime();
    pressingSpell2LastTime = CACurrentMediaTime();
    pressingSpell3LastTime = CACurrentMediaTime();
    pressingSpell4LastTime = CACurrentMediaTime();
    pressingActivesLastTime = CACurrentMediaTime();
}
- (IBAction)turnOnOff:(id)sender {
    keyQPressed = 0;
    keyWPressed = 0;
    keyEPressed = 0;
    keyRPressed = 0;
    
    pressingSpell1 = false;
    pressingSpell2 = false;
    pressingSpell3 = false;
    pressingSpell4 = false;
    
    pressingSpell1LastTime = 0;
    pressingSpell2LastTime = 0;
    pressingSpell3LastTime = 0;
    pressingSpell4LastTime = 0;
    
    pressingActivesLastTime = 0;
    running = !running;
}
- (IBAction)active1OnOff:(id)sender {
    active1On = !active1On;
}
- (IBAction)active2OnOff:(id)sender {
    active2On = !active2On;
}
- (IBAction)active3OnOff:(id)sender {
    active3On = !active3On;
}
- (IBAction)active5OnOff:(id)sender {
    active5On = !active5On;
}
- (IBAction)active6OnOff:(id)sender {
    active6On = !active6On;
}
- (IBAction)active7OnOff:(id)sender {
    active7On = !active7On;
}
- (IBAction)activeWardOnOff:(id)sender {
    activeWardOn = !activeWardOn;
}

- (IBAction)qValueChanged:(NSTextField*)sender {
    pressSpell1Interval = [sender.value doubleValue];
}
- (IBAction)wValueChanged:(NSTextField*)sender {
    pressSpell2Interval = [sender.value doubleValue];
}
- (IBAction)eValueChanged:(NSTextField*)sender {
    pressSpell3Interval = [sender.value doubleValue];
}
- (IBAction)rValueChanged:(NSTextField*)sender {
    pressSpell4Interval = [sender.value doubleValue];
}
- (IBAction)activeValueChanged:(NSTextField*)sender {
    pressActivesInterval = [sender.value doubleValue];
}
- (IBAction)activeKeyChanged:(NSComboBox*)sender {
    activeKey = [sender.value characterAtIndex:0];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}
static AppDelegate *globalSelf;
CGEventRef myCGEventCallback(CGEventTapProxy proxy, CGEventType type,
                             CGEventRef event, void *refcon)
{
    CGKeyCode keycode = (CGKeyCode)CGEventGetIntegerValueField(event, kCGKeyboardEventKeycode);
    
    if (keycode == 12) { //Q
        if (type == kCGEventKeyDown) {
            keyQPressed = true;
        } else if (type == kCGEventKeyUp) {
            keyQPressed = false;
        }
    }
    if (keycode == 13) { //W
        if (type == kCGEventKeyDown) {
            keyWPressed = true;
        } else if (type == kCGEventKeyUp) {
            keyWPressed = false;
        }
    }
    if (keycode == 14) { //E
        if (type == kCGEventKeyDown) {
            keyEPressed = true;
        } else if (type == kCGEventKeyUp) {
            keyEPressed  = false;
        }
    }
    if (keycode == 15) { //R
        if (type == kCGEventKeyDown) {
            keyRPressed = true;
        } else if (type == kCGEventKeyUp) {
            keyRPressed = false;
        }
    }
    if (keycode == 12 || keycode == 13 || keycode == 14 || keycode == 15) {
        [globalSelf runLogicPress];
    }
    return event;
}


- (void)timerLogic {
    if (running) {
        if (pressingSpell1) {
            CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingSpell1LastTime;
            if (elapsedTime >= pressSpell1Interval/1000.0) {
                [self tapSpell1];
                pressingSpell1LastTime = CACurrentMediaTime();
            }
            if (activeKey == 'Q') {[self activateActives];}
        }
        if (pressingSpell2) {
            CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingSpell2LastTime;
            if (elapsedTime >= pressSpell2Interval/1000.0) {
                [self tapSpell2];
                pressingSpell2LastTime = CACurrentMediaTime();
            }
            if (activeKey == 'W') {[self activateActives];}
        }
        if (pressingSpell3) {
            CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingSpell3LastTime;
            if (elapsedTime >= pressSpell3Interval/1000.0) {
                [self tapSpell3];
                pressingSpell3LastTime = CACurrentMediaTime();
            }
            if (activeKey == 'E') {[self activateActives];}
        }
        if (pressingSpell4) {
            CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingSpell4LastTime;
            if (elapsedTime >= pressSpell4Interval/1000.0) {
                [self tapSpell4];
                pressingSpell4LastTime = CACurrentMediaTime();
            }
            if (activeKey == 'R') {[self activateActives];}
        }
        if (activeWardOn) {
            CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingWardLastTime;
            if (elapsedTime >= 12.04) {
                [self tapWard];
                pressingWardLastTime = CACurrentMediaTime();
            }
        }
    }
}
- (void) activateActives {
    CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingActivesLastTime;
    if (elapsedTime >= pressActivesInterval/1000.0) {
        if (active1On) {
            [self tapActive1];
        }
        if (active2On) {
            [self tapActive2];
        }
        if (active3On) {
            [self tapActive3];
        }
        if (active5On) {
            [self tapActive5];
        }
        if (active6On) {
            [self tapActive6];
        }
        if (active7On) {
            [self tapActive7];
        }
        pressingActivesLastTime = CACurrentMediaTime();
    }
}

- (void)runLogicPress {
    pressingSpell1 = keyQPressed;
    pressingSpell2 = keyWPressed;
    pressingSpell3 = keyEPressed;
    pressingSpell4 = keyRPressed;
}



- (void)tapSpell1 {
    [self pressSpell1];
    [self releaseSpell1];
}
- (void)tapSpell2 {
    [self pressSpell2];
    [self releaseSpell2];
}
- (void)tapSpell3 {
    [self pressSpell3];
    [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(releaseSpell3) userInfo:nil repeats:NO];
    //[self releaseSpell3];
}
- (void)tapSpell4 {
    [self pressSpell4];
    [self releaseSpell4];
}
- (void)tapActive1 {
    [self pressActive1];
    [self releaseActive1];
}
- (void)tapActive2 {
    [self pressActive2];
    [self releaseActive2];
}
- (void)tapActive3 {
    [self pressActive3];
    [self releaseActive3];
}
- (void)tapActive5 {
    [self pressActive5];
    [self releaseActive5];
}
- (void)tapActive6 {
    [self pressActive6];
    [self releaseActive6];
}
- (void)tapActive7 {
    [self pressActive7];
    [self releaseActive7];
}
- (void)tapWard {
    [self pressWard];
    [self releaseWard];
}
- (void)pressSpell1 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 6, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseSpell1 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 6, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressSpell2 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 7, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseSpell2 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 7, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressSpell3 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 8, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseSpell3 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 8, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressSpell4 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 9, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseSpell4 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 9, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive1 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 18, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive1 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 18, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive2 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 19, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive2 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 19, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive3 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 20, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive3 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 20, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressWard {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 21, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseWard {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 21, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}




- (void)pressActive5 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 22, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive5 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 22, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive6 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 23, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive6 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 23, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive7 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 24, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive7 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 24, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}



- (void)releaseQ {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 12, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseW {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 13, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseE {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 14, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseR {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 15, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)createTap
{
    CFMachPortRef      eventTap;
    CGEventMask        eventMask;
    CFRunLoopSourceRef runLoopSource;
    
    // Create an event tap. We are interested in key presses.
    eventMask = ((1 << kCGEventKeyDown) | (1 << kCGEventKeyUp) | (1 << kCGEventFlagsChanged));
    eventTap = CGEventTapCreate(kCGSessionEventTap, kCGEventTapOptionListenOnly, 0,
                                eventMask, myCGEventCallback, NULL);
    if (!eventTap) {
        fprintf(stderr, "failed to create event tap\n");
        exit(1);
    }
    
    // Create a run loop source.
    runLoopSource = CFMachPortCreateRunLoopSource(
                                                  kCFAllocatorDefault, eventTap, 0);
    
    // Add to the current run loop.
    CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource,
                       kCFRunLoopCommonModes);
    
    // Enable the event tap.
    CGEventTapEnable(eventTap, true);
    
    // Set it all running.
    CFRunLoopRun();
    
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication {
    return YES;
}

@end
