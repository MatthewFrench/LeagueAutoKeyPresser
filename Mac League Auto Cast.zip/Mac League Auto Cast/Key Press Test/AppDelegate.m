//
//  AppDelegate.m
//  Key Press Test
//
//  Created by Matthew French on 4/4/15.
//  Copyright (c) 2015 Matthew French. All rights reserved.
//

#import "AppDelegate.h"
#import <ApplicationServices/ApplicationServices.h>

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

NSTimer* timer = NULL;

bool keyQPressed = false;
bool keyWPressed = false;
bool keyEPressed = false;
bool keyRPressed = false;
bool keyTPressed = false;

bool pressingSpell1 = false;
bool pressingSpell2 = false;
bool pressingSpell3 = false;
bool pressingSpell4 = false;

CFTimeInterval pressingSpell1LastTime = 0;
CFTimeInterval pressingSpell2LastTime = 0;
CFTimeInterval pressingSpell3LastTime = 0;
CFTimeInterval pressingSpell4LastTime = 0;

CFTimeInterval pressedDLastTime = 0;
CFTimeInterval pressedFLastTime = 0;

CFTimeInterval pressingActivesLastTime = 0;

CFTimeInterval pressingWardLastTime = 0;

CFTimeInterval wardHopLastTime = 0;

double pressSpell1Interval = 10;
double pressSpell2Interval = 10;
double pressSpell3Interval = 10;
double pressSpell4Interval = 100;
double pressActivesInterval = 100;

bool running = true;
bool active1On = false;
bool active2On = false;
bool active3On = false;
bool active5On = false;
bool active6On = false;
bool active7On = false;
bool activeWardOn = false;

bool wardHopOn = false;
bool qPreactivateW = false;
bool qPreactivateE = false;
bool qPreactivateR = false;

bool wPreactivateQ = false;
bool wPreactivateE = false;
bool wPreactivateR = false;

bool ePreactivateQ = false;
bool ePreactivateW = false;
bool ePreactivateR = false;

bool rPreactivateQ = false;
bool rPreactivateW = false;
bool rPreactivateE = false;

char wardHopKey = 'Q';

char activeKey = 'E';

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults boolForKey:@"saved"] == YES) {
        wardHopKey = [defaults integerForKey:@"wardHopKey"];
        activeKey = [defaults integerForKey:@"activeKey"];
        pressSpell1Interval = [defaults doubleForKey:@"pressSpell1Interval"];
        pressSpell2Interval = [defaults doubleForKey:@"pressSpell2Interval"];
        pressSpell3Interval = [defaults doubleForKey:@"pressSpell3Interval"];
        pressSpell4Interval = [defaults doubleForKey:@"pressSpell4Interval"];
        pressActivesInterval = [defaults doubleForKey:@"pressActivesInterval"];
        running = [defaults boolForKey:@"running"];
        active1On = [defaults boolForKey:@"active1On"];
        active2On = [defaults boolForKey:@"active2On"];
        active3On = [defaults boolForKey:@"active3On"];
        active5On = [defaults boolForKey:@"active5On"];
        active6On = [defaults boolForKey:@"active6On"];
        active7On = [defaults boolForKey:@"active7On"];
        activeWardOn = [defaults boolForKey:@"activeWardOn"];
        wardHopOn = [defaults boolForKey:@"wardHopOn"];
        qPreactivateW = [defaults boolForKey:@"qPreactivateW"];
        qPreactivateE = [defaults boolForKey:@"qPreactivateE"];
        qPreactivateR = [defaults boolForKey:@"qPreactivateR"];
        wPreactivateQ = [defaults boolForKey:@"wPreactivateQ"];
        wPreactivateE = [defaults boolForKey:@"wPreactivateE"];
        wPreactivateR = [defaults boolForKey:@"wPreactivateR"];
        ePreactivateQ = [defaults boolForKey:@"ePreactivateQ"];
        ePreactivateW = [defaults boolForKey:@"ePreactivateW"];
        ePreactivateR = [defaults boolForKey:@"ePreactivateR"];
        rPreactivateQ = [defaults boolForKey:@"rPreactivateQ"];
        rPreactivateW = [defaults boolForKey:@"rPreactivateW"];
        rPreactivateE = [defaults boolForKey:@"rPreactivateE"];
    }
    [wardHopKeyComboBox setStringValue:[NSString stringWithFormat:@"%c",wardHopKey]];
    [activeKeyComboBox setStringValue:[NSString stringWithFormat:@"%c",activeKey]];
    [pressSpell1IntervalText setIntegerValue:pressSpell1Interval];
    [pressSpell2IntervalText setIntegerValue:pressSpell2Interval];
    [pressSpell3IntervalText setIntegerValue:pressSpell3Interval];
    [pressSpell4IntervalText setIntegerValue:pressSpell4Interval];
    [pressActivesIntervalText setIntegerValue:pressActivesInterval];
    [runningCheckBox setState:running];
    [active1OnCheckBox setState:active1On];
    [active2OnCheckBox setState:active2On];
    [active3OnCheckBox setState:active3On];
    [active5OnCheckBox setState:active5On];
    [active6OnCheckBox setState:active6On];
    [active7OnCheckBox setState:active7On];
    [activeWardOnCheckBox setState:activeWardOn];
    [wardHopOnCheckBox setState:wardHopOn];
    [qPreactivateWCheckBox setState:qPreactivateW];
    [qPreactivateECheckBox setState:qPreactivateE];
    [qPreactivateRCheckBox setState:qPreactivateR];
    [wPreactivateQCheckBox setState:wPreactivateQ];
    [wPreactivateECheckBox setState:wPreactivateE];
    [wPreactivateRCheckBox setState:wPreactivateR];
    [ePreactivateQCheckBox setState:ePreactivateQ];
    [ePreactivateWCheckBox setState:ePreactivateW];
    [ePreactivateRCheckBox setState:ePreactivateR];
    [rPreactivateQCheckBox setState:rPreactivateQ];
    [rPreactivateWCheckBox setState:rPreactivateW];
    [rPreactivateECheckBox setState:rPreactivateE];
    
    //retrieving
    //[defaults boolForKey:@"testBool"];
    [self.window setRestorable:true];
    
    
    
    
    // Insert code here to initialize your application
    globalSelf = self;
    [self createTap];
    
    pressingSpell1LastTime = CACurrentMediaTime();
    pressingSpell2LastTime = CACurrentMediaTime();
    pressingSpell3LastTime = CACurrentMediaTime();
    pressingSpell4LastTime = CACurrentMediaTime();
    pressingActivesLastTime = CACurrentMediaTime();
    
    [self.window makeKeyAndOrderFront:self];
    [self.window setOrderedIndex:0];
    [NSApp activateIgnoringOtherApps:YES];
    
    
    [[NSProcessInfo processInfo] disableAutomaticTermination:@"Good Reason"];
    
    if ([[NSProcessInfo processInfo] respondsToSelector:@selector(beginActivityWithOptions:reason:)]) {
        self->activity = [[NSProcessInfo processInfo] beginActivityWithOptions:0x00FFFFFF reason:@"receiving messages"];
    }
    /*
    [[NSProcessInfo processInfo] beginActivityWithOptions:NSActivityIdleSystemSleepDisabled| NSActivitySuddenTerminationDisabled reason:@"Good Reason 2"];
    
    [[NSProcessInfo processInfo] beginActivityWithOptions:NSActivityUserInitiated | NSActivityLatencyCritical reason:@"Good Reason 3"];
     */
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0/2000.0
                                             target:self
                                           selector:@selector(timerLogic)
                                           userInfo:nil
                                            repeats:YES];

}
- (IBAction)turnOnOff:(NSButton*)sender {
    keyQPressed = 0;
    keyWPressed = 0;
    keyEPressed = 0;
    keyRPressed = 0;
    
    pressingSpell1 = false;
    pressingSpell2 = false;
    pressingSpell3 = false;
    pressingSpell4 = false;
    
    pressingSpell1LastTime = 0;
    pressingSpell2LastTime = 0;
    pressingSpell3LastTime = 0;
    pressingSpell4LastTime = 0;
    
    pressingActivesLastTime = 0;
    running = !running;
    [self removeFocus];
}
- (IBAction)active1OnOff:(id)sender {
    active1On = !active1On;
    [self removeFocus];
}
- (IBAction)active2OnOff:(id)sender {
    active2On = !active2On;
    [self removeFocus];
}
- (IBAction)active3OnOff:(id)sender {
    active3On = !active3On;
    [self removeFocus];
}
- (IBAction)active5OnOff:(id)sender {
    active5On = !active5On;
    [self removeFocus];
}
- (IBAction)active6OnOff:(id)sender {
    active6On = !active6On;
    [self removeFocus];
}
- (IBAction)active7OnOff:(id)sender {
    active7On = !active7On;
    [self removeFocus];
}
- (IBAction)activeWardOnOff:(id)sender {
    activeWardOn = !activeWardOn;
    [self removeFocus];
}

- (void)removeFocus {
    [[self window] makeFirstResponder:nil];
}
- (void)controlTextDidChange:(NSNotification *)aNotification {
    NSTextField* sender = [aNotification object];
    if (sender == pressSpell1IntervalText) {
        if ([[sender stringValue] length] == 0) {
            pressSpell1Interval = 0;
        } else {
            pressSpell1Interval = [sender doubleValue];
        }
    }
    if (sender == pressSpell2IntervalText) {
        if ([[sender stringValue] length] == 0) {
            pressSpell2Interval = 0;
        } else {
            pressSpell2Interval = [sender doubleValue];
        }
    }
    if (sender == pressSpell3IntervalText) {
        if ([[sender stringValue] length] == 0) {
            pressSpell3Interval = 0;
        } else {
            pressSpell3Interval = [sender doubleValue];
        }
    }
    if (sender == pressSpell4IntervalText) {
        if ([[sender stringValue] length] == 0) {
            pressSpell4Interval = 0;
        } else {
            pressSpell4Interval = [sender doubleValue];
        }
    }
    if (sender == pressActivesIntervalText) {
        if ([[sender stringValue] length] == 0) {
            pressActivesInterval = 0;
        } else {
            pressActivesInterval = [sender doubleValue];
        }
    }
}
- (IBAction)activeKeyChanged:(NSComboBox*)sender {
    activeKey = [[sender stringValue] characterAtIndex:0];
    [self removeFocus];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
    //saving
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setInteger:YES forKey:@"saved"];
    [defaults setInteger:wardHopKey forKey:@"wardHopKey"];
    [defaults setInteger:activeKey forKey:@"activeKey"];
    [defaults setDouble:pressSpell1Interval forKey:@"pressSpell1Interval"];
    [defaults setDouble:pressSpell2Interval forKey:@"pressSpell2Interval"];
    [defaults setDouble:pressSpell3Interval forKey:@"pressSpell3Interval"];
    [defaults setDouble:pressSpell4Interval forKey:@"pressSpell4Interval"];
    [defaults setDouble:pressActivesInterval forKey:@"pressActivesInterval"];
    [defaults setBool:running forKey:@"running"];
    [defaults setBool:active1On forKey:@"active1On"];
    [defaults setBool:active2On forKey:@"active2On"];
    [defaults setBool:active3On forKey:@"active3On"];
    [defaults setBool:active5On forKey:@"active5On"];
    [defaults setBool:active6On forKey:@"active6On"];
    [defaults setBool:active7On forKey:@"active7On"];
    [defaults setBool:activeWardOn forKey:@"activeWardOn"];
    [defaults setBool:wardHopOn forKey:@"wardHopOn"];
    [defaults setBool:qPreactivateW forKey:@"qPreactivateW"];
    [defaults setBool:qPreactivateE forKey:@"qPreactivateE"];
    [defaults setBool:qPreactivateR forKey:@"qPreactivateR"];
    [defaults setBool:wPreactivateQ forKey:@"wPreactivateQ"];
    [defaults setBool:wPreactivateE forKey:@"wPreactivateE"];
    [defaults setBool:wPreactivateR forKey:@"wPreactivateR"];
    [defaults setBool:ePreactivateQ forKey:@"ePreactivateQ"];
    [defaults setBool:ePreactivateW forKey:@"ePreactivateW"];
    [defaults setBool:ePreactivateR forKey:@"ePreactivateR"];
    [defaults setBool:rPreactivateQ forKey:@"rPreactivateQ"];
    [defaults setBool:rPreactivateW forKey:@"rPreactivateW"];
    [defaults setBool:rPreactivateE forKey:@"rPreactivateE"];
}
static AppDelegate *globalSelf;
CGEventRef myCGEventCallback(CGEventTapProxy proxy, CGEventType type,
                             CGEventRef event, void *refcon)
{
    CGKeyCode keycode = (CGKeyCode)CGEventGetIntegerValueField(event, kCGKeyboardEventKeycode);
    
    if (keycode == 17) { //T key
        if (type == kCGEventKeyDown) {
            keyTPressed = true;
        } else if (type == kCGEventKeyUp) {
            keyTPressed = false;
            wardHopLastTime = 0;
        }
    }
    
    if (keycode == 12) { //Q
        if (type == kCGEventKeyDown) {
            keyQPressed = true;
            pressingSpell1LastTime = 0;
        } else if (type == kCGEventKeyUp) {
            keyQPressed = false;
        }
    }
    if (keycode == 13) { //W
        if (type == kCGEventKeyDown) {
            keyWPressed = true;
            pressingSpell2LastTime = 0;
        } else if (type == kCGEventKeyUp) {
            keyWPressed = false;
        }
    }
    if (keycode == 14) { //E
        if (type == kCGEventKeyDown) {
            keyEPressed = true;
            pressingSpell3LastTime = 0;
        } else if (type == kCGEventKeyUp) {
            keyEPressed  = false;
        }
    }
    if (keycode == 15) { //R
        if (type == kCGEventKeyDown) {
            keyRPressed = true;
            pressingSpell4LastTime = 0;
        } else if (type == kCGEventKeyUp) {
            keyRPressed = false;
        }
    }
    if ((keycode == 12 || keycode == 13 || keycode == 14 || keycode == 15 || keycode == 17)  && running) {
        [globalSelf runLogicPress];
        return NULL;
    }
    return event;
}

CFTimeInterval lastTime;
int writeEvery = 500;
int currentWrite = 0;
double avg = 0;

- (void)timerLogic {
    
     if (currentWrite >= writeEvery)
     {
     //CFTimeInterval elapsedTime2 = CACurrentMediaTime() - lastTime;
     NSLog(@"Elapsed Time: %f milliseconds", avg *1000.0/writeEvery);
     lastTime = CACurrentMediaTime();
     currentWrite = 0;
         avg = 0;
     }
     else
     {
     currentWrite++;
         avg += CACurrentMediaTime() - lastTime;
     lastTime = CACurrentMediaTime();
     }
    
    
    if (running) {
        //Ward hop
        if (keyTPressed && wardHopOn) {
            //Place ward
            CFTimeInterval elapsedTime = CACurrentMediaTime() - wardHopLastTime;
            if (elapsedTime >= 1.0) {
                wardHopLastTime =CACurrentMediaTime();
                [self tapWard];
            }
            //Try to hop
            if (wardHopKey == 'Q') [self preactivateQ:pressSpell1Interval];
            if (wardHopKey == 'W') [self preactivateW:pressSpell2Interval];
            if (wardHopKey == 'E') [self preactivateE:pressSpell3Interval];
            if (wardHopKey == 'R') [self preactivateR:pressSpell4Interval];
        }
        
        
        if (pressingSpell1) {
            if (qPreactivateW) [self preactivateW:pressSpell1Interval];
            if (qPreactivateE) [self preactivateE:pressSpell1Interval];
            if (qPreactivateR) [self preactivateR:pressSpell1Interval];
            [self preactivateQ:pressSpell1Interval];
            if (activeKey == 'Q') {[self activateActives];}
        }
        if (pressingSpell2) {
            if (wPreactivateQ) [self preactivateQ:pressSpell2Interval];
            if (wPreactivateE) [self preactivateE:pressSpell2Interval];
            if (wPreactivateR) [self preactivateR:pressSpell2Interval];
            [self preactivateW:pressSpell2Interval];
            if (activeKey == 'W') {[self activateActives];}
        }
        if (pressingSpell3) {
            if (ePreactivateQ) [self preactivateQ:pressSpell3Interval];
            if (ePreactivateW) [self preactivateW:pressSpell3Interval];
            if (ePreactivateR) [self preactivateR:pressSpell3Interval];
            [self preactivateE:pressSpell3Interval];
            if (activeKey == 'E') {[self activateActives];}
        }
        if (pressingSpell4) {
            if (rPreactivateQ) [self preactivateQ:pressSpell4Interval];
            if (rPreactivateW) [self preactivateW:pressSpell4Interval];
            if (rPreactivateE) [self preactivateE:pressSpell4Interval];
            [self preactivateR:pressSpell4Interval];
            if (activeKey == 'R') {[self activateActives];}
        }
    }
}
- (void) preactivateQ:(double)interval {
    CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingSpell1LastTime;
    if (elapsedTime >= interval/1000.0) {
        pressingSpell1LastTime = CACurrentMediaTime();
        [self tapSpell1];
    }
}
- (void) preactivateW:(double)interval {
    CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingSpell2LastTime;
    if (elapsedTime >= interval/1000.0) {
        pressingSpell2LastTime = CACurrentMediaTime();
        [self tapSpell2];
    }
}
- (void) preactivateE:(double)interval {
    CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingSpell3LastTime;
    if (elapsedTime >= interval/1000.0) {
        pressingSpell3LastTime = CACurrentMediaTime();
        [self tapSpell3];
    }
}
- (void) preactivateR:(double)interval {
    CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingSpell4LastTime;
    if (elapsedTime >= interval/1000.0) {
        pressingSpell4LastTime = CACurrentMediaTime();
        [self tapSpell4];
    }
}
- (void) activateActives {
    CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingActivesLastTime;
    if (elapsedTime >= pressActivesInterval/1000.0) {
        pressingActivesLastTime = CACurrentMediaTime();
        if (active1On) {
            [self tapActive1];
        }
        if (active2On) {
            [self tapActive2];
        }
        if (active3On) {
            [self tapActive3];
        }
        if (active5On) {
            [self tapActive5];
        }
        if (active6On) {
            [self tapActive6];
        }
        if (active7On) {
            [self tapActive7];
        }
    }
    if (activeWardOn) {
        CFTimeInterval elapsedTime = CACurrentMediaTime() - pressingWardLastTime;
        if (elapsedTime >= 6.0) {
            pressingWardLastTime = CACurrentMediaTime();
            [self tapWard];
        }
    }
}

- (void)runLogicPress {
    pressingSpell1 = keyQPressed;
    pressingSpell2 = keyWPressed;
    pressingSpell3 = keyEPressed;
    pressingSpell4 = keyRPressed;
    /*
    //Do a reset on the keys
    [self releaseSpell1];
    [self releaseSpell2];
    [self releaseSpell3];
    [self releaseSpell4];
    if (pressingSpell1) [self tapSpell1];
    if (pressingSpell2) [self tapSpell2];
    if (pressingSpell3) [self tapSpell3];
    if (pressingSpell4) [self tapSpell4];
     */
    [self timerLogic];
}

- (void)tapSpell1 {
    [self pressSpell1];
    [self releaseSpell1];
}
- (void)tapSpell2 {
    [self pressSpell2];
    [self releaseSpell2];
}
- (void)tapSpell3 {
    [self pressSpell3];
    [self releaseSpell3];
}
- (void)tapSpell4 {
    [self pressSpell4];
    [self releaseSpell4];
}
- (void)tapActive1 {
    [self pressActive1];
    [self releaseActive1];
}
- (void)tapActive2 {
    [self pressActive2];
    [self releaseActive2];
}
- (void)tapActive3 {
    [self pressActive3];
    [self releaseActive3];
}
- (void)tapActive5 {
    [self pressActive5];
    [self releaseActive5];
}
- (void)tapActive6 {
    [self pressActive6];
    [self releaseActive6];
}
- (void)tapActive7 {
    [self pressActive7];
    [self releaseActive7];
}
- (void)tapWard {
    [self pressWard];
    [self releaseWard];
}
- (void)pressSpell1 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 6, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseSpell1 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 6, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressSpell2 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 7, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseSpell2 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 7, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressSpell3 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 8, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseSpell3 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 8, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressSpell4 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 9, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseSpell4 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 9, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive1 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 18, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive1 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 18, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive2 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 19, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive2 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 19, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive3 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 20, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive3 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 20, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressWard {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 21, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseWard {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 21, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}




- (void)pressActive5 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 22, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive5 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 22, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive6 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 23, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive6 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 23, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressActive7 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 24, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseActive7 {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 24, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}

- (void)pressD {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 2, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseD {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 2, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)pressF {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 3, YES);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseF {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 3, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}



- (void)releaseQ {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 12, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseW {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 13, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseE {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 14, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)releaseR {
    CGEventRef event = CGEventCreateKeyboardEvent(NULL, 15, NO);
    CGEventPost(kCGHIDEventTap, event);
    CFRelease(event);
}
- (void)createTap
{
    CFMachPortRef      eventTap;
    CGEventMask        eventMask;
    CFRunLoopSourceRef runLoopSource;
    
    // Create an event tap. We are interested in key presses.
    eventMask = ((1 << kCGEventKeyDown) | (1 << kCGEventKeyUp) | (1 << kCGEventFlagsChanged));
    eventTap = CGEventTapCreate(kCGSessionEventTap, kCGEventTapOptionListenOnly, 0,
                                eventMask, myCGEventCallback, NULL);
    if (!eventTap) {
        fprintf(stderr, "failed to create event tap\n");
        exit(1);
    }
    
    // Create a run loop source.
    runLoopSource = CFMachPortCreateRunLoopSource(
                                                  kCFAllocatorDefault, eventTap, 0);
    
    // Add to the current run loop.
    CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource,
                       kCFRunLoopCommonModes);
    
    // Enable the event tap.
    CGEventTapEnable(eventTap, true);
    
    // Set it all running.
    CFRunLoopRun();
    
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication {
    return YES;
}







- (IBAction)qPreactivateW:(id)sender {
    qPreactivateW = !qPreactivateW;
}
- (IBAction)qPreactivateE:(id)sender {
    qPreactivateE = !qPreactivateE;
}
- (IBAction)qPreactivateR:(id)sender {
    qPreactivateR = !qPreactivateR;
}

- (IBAction)wPreactivateQ:(id)sender {
    wPreactivateQ = !wPreactivateQ;
}
- (IBAction)wPreactivateE:(id)sender {
    wPreactivateE = !wPreactivateE;
}
- (IBAction)wPreactivateR:(id)sender {
    wPreactivateR = !wPreactivateR;
}

- (IBAction)ePreactivateQ:(id)sender {
    ePreactivateQ = !ePreactivateQ;
}
- (IBAction)ePreactivateW:(id)sender {
    ePreactivateW = !ePreactivateW;
}
- (IBAction)ePreactivateR:(id)sender {
    ePreactivateR = !ePreactivateR;
}

- (IBAction)rPreactivateQ:(id)sender {
    rPreactivateQ = !rPreactivateQ;
}
- (IBAction)rPreactivateW:(id)sender {
    rPreactivateW = !rPreactivateW;
}
- (IBAction)rPreactivateE:(id)sender {
    rPreactivateE = !rPreactivateE;
}

- (IBAction)wardHopOnOff:(id)sender {
    wardHopOn = !wardHopOn;
}
- (IBAction)wardHopKeyChanged:(NSComboBox*)sender {
    wardHopKey = [[sender stringValue] characterAtIndex:0];
    [self removeFocus];
}







@end